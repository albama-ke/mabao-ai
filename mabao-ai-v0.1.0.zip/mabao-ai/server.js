const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Load a local .env file without requiring dotenv. Hosting platforms can still inject normal environment variables.
(function loadDotEnv(){
  try {
    const envPath = path.join(__dirname, '.env');
    if (!fs.existsSync(envPath)) return;
    for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
      const i = trimmed.indexOf('=');
      const key = trimmed.slice(0, i).trim();
      const value = trimmed.slice(i + 1).trim().replace(/^['"]|['"]$/g, '');
      if (!(key in process.env)) process.env[key] = value;
    }
  } catch (e) { console.warn('Could not load .env:', e.message); }
})();

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'mabao-dev-secret-change-me';
const API_KEY = process.env.API_FOOTBALL_KEY || '';
const API_BASE = process.env.API_FOOTBALL_BASE || 'https://v3.football.api-sports.io';
const DEMO_MODE = String(process.env.DEMO_MODE || '').toLowerCase() === 'true' || !API_KEY;
const PUBLIC = path.join(__dirname, 'public');
const users = new Map();
const cache = new Map();
const CACHE_TTL_MS = 45_000;

const demoFixtures = [
  { fixture:{id:900001,date:'2026-09-25T17:30:00+00:00',status:{short:'NS',elapsed:null}},league:{id:39,name:'Premier League',country:'England',logo:''},teams:{home:{id:101,name:'Arsenal',logo:''},away:{id:102,name:'Chelsea',logo:''}},goals:{home:null,away:null}},
  { fixture:{id:900002,date:'2026-09-25T18:00:00+00:00',status:{short:'LIVE',elapsed:64}},league:{id:140,name:'La Liga',country:'Spain',logo:''},teams:{home:{id:103,name:'Barcelona',logo:''},away:{id:104,name:'Sevilla',logo:''}},goals:{home:2,away:1}},
  { fixture:{id:900003,date:'2026-09-24T20:00:00+00:00',status:{short:'FT',elapsed:90}},league:{id:135,name:'Serie A',country:'Italy',logo:''},teams:{home:{id:105,name:'Inter',logo:''},away:{id:106,name:'Milan',logo:''}},goals:{home:3,away:2}},
  { fixture:{id:900004,date:'2026-09-25T19:00:00+00:00',status:{short:'NS',elapsed:null}},league:{id:61,name:'Ligue 1',country:'France',logo:''},teams:{home:{id:107,name:'PSG',logo:''},away:{id:108,name:'Lyon',logo:''}},goals:{home:null,away:null}}
];

const demoCountries = [
  'Argentina','Australia','Belgium','Brazil','Egypt','England','France','Germany','Ghana','Italy','Japan','Kenya','Mexico','Morocco','Netherlands','Nigeria','Portugal','Senegal','South Africa','Spain','Tanzania','Uganda','United States','Zambia'
].map(name=>({code:name.slice(0,2).toUpperCase(),name}));
const demoLeagues = [
  [39,'Premier League','England'],[140,'La Liga','Spain'],[135,'Serie A','Italy'],[61,'Ligue 1','France'],[94,'Primeira Liga','Portugal'],[71,'Serie A','Brazil'],[88,'Eredivisie','Netherlands'],[322,'Premier Soccer League','South Africa'],[276,'Kenyan Premier League','Kenya']
].map(([id,name,country])=>({id,name,country,type:'League',logo:''}));

function json(res,status,payload){
  const body=JSON.stringify(payload);
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});
  res.end(body);
}
function readBody(req){return new Promise((resolve,reject)=>{let d='';req.on('data',c=>{d+=c;if(d.length>1_000_000){reject(new Error('Payload too large'));req.destroy();}});req.on('end',()=>{try{resolve(d?JSON.parse(d):{})}catch{resolve({})}});req.on('error',reject)})}
function tokenFor(user){const payload=Buffer.from(JSON.stringify({id:user.id,email:user.email,name:user.name,exp:Date.now()+30*24*60*60*1000})).toString('base64url');const sig=crypto.createHmac('sha256',JWT_SECRET).update(payload).digest('base64url');return payload+'.'+sig}
function userFromReq(req){const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return null;const [payload,sig]=h.slice(7).split('.');if(!payload||!sig)return null;const expected=crypto.createHmac('sha256',JWT_SECRET).update(payload).digest('base64url');if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return null;try{const p=JSON.parse(Buffer.from(payload,'base64url').toString());if(p.exp<Date.now())return null;return p}catch{return null}}
function hashPassword(password){const salt=crypto.randomBytes(16).toString('hex');const hash=crypto.scryptSync(password,salt,64).toString('hex');return {salt,hash}}
function verifyPassword(password,u){const hash=crypto.scryptSync(password,u.salt,64).toString('hex');return crypto.timingSafeEqual(Buffer.from(hash,'hex'),Buffer.from(u.passwordHash,'hex'))}
function publicUser(u){return{id:u.id,name:u.name,email:u.email,favorites:u.favorites}}
function id(){return crypto.randomBytes(12).toString('hex')}

async function footballApi(endpoint, params={}){
  if(DEMO_MODE)return null;
  const q=new URLSearchParams();for(const [k,v] of Object.entries(params)){if(v!==undefined&&v!==null&&v!=='')q.set(k,v)}
  const response=await fetch(`${API_BASE}${endpoint}?${q.toString()}`,{headers:{'x-apisports-key':API_KEY,Accept:'application/json'}});
  const text=await response.text();let data;try{data=JSON.parse(text)}catch{throw new Error(`Football API returned non-JSON (${response.status})`)}
  if(!response.ok)throw new Error(data.message||`Football API error ${response.status}`);
  if(data.errors&&Object.keys(data.errors).length)throw new Error(JSON.stringify(data.errors));
  return data;
}
async function cached(key,fn,ttl=CACHE_TTL_MS){const hit=cache.get(key);if(hit&&Date.now()-hit.at<ttl)return hit.value;const value=await fn();cache.set(key,{at:Date.now(),value});return value}
function predictionFromProvider(raw){const p=raw?.percent||{};const home=Number.parseFloat(p.home||0),draw=Number.parseFloat(p.draw||0),away=Number.parseFloat(p.away||0),m=Math.max(home,draw,away);const winner=m===home?'Home Win':m===draw?'Draw':'Away Win';return{model:'Mabao AI Analytical Model',winner,confidence:Math.min(97,Math.round(55+m*.42)),home,draw,away,predictedScore:raw?.goals?.home!==undefined&&raw?.goals?.away!==undefined?`${raw.goals.home}-${raw.goals.away}`:'—',underOver:raw?.goals?.under_over||raw?.under_over||'',btts:raw?.under_over||'Not available',advice:raw?.advice||raw?.winner?.comment||'Insufficient data for a firm market view.',raw};}
function demoPrediction(f){return{model:'Mabao AI Analytical Model • Demo',winner:'Home Win',confidence:82,home:62,draw:22,away:16,predictedScore:'2-1',underOver:'Over 2.5',btts:'Yes',advice:`The model leans toward ${f.teams.home.name} using a blended form, home advantage and scoring-trend simulation. Demo data is active.`}}

async function apiRoute(method, url, req, res){
  const parts=url.pathname.split('/').filter(Boolean);
  try{
    if(method==='GET'&&url.pathname==='/api/health')return json(res,200,{ok:true,service:'Mabao AI',demoMode:DEMO_MODE,provider:'API-Football compatible'});
    if(method==='GET'&&url.pathname==='/api/countries'){
      const data=await cached('countries',()=>footballApi('/countries'),24*60*60*1000);return json(res,200,data?data.response:demoCountries);
    }
    if(method==='GET'&&url.pathname==='/api/leagues'){
      const country=url.searchParams.get('country')||'';const data=await cached(`leagues:${country}`,()=>footballApi('/leagues',{country}),6*60*60*1000);
      if(data)return json(res,200,data.response.map(x=>({...x.league,country:x.country?.name||country,logo:x.league?.logo})));
      return json(res,200,country?demoLeagues.filter(x=>x.country.toLowerCase()===country.toLowerCase()):demoLeagues);
    }
    if(method==='GET'&&url.pathname==='/api/fixtures'){
      const date=url.searchParams.get('date')||new Date().toISOString().slice(0,10),timezone=url.searchParams.get('timezone')||'Africa/Nairobi',league=url.searchParams.get('league')||'',season=url.searchParams.get('season')||'',team=url.searchParams.get('team')||'';
      const key=`fixtures:${date}:${timezone}:${league}:${season}:${team}`;const data=await cached(key,()=>footballApi('/fixtures',{date,timezone,league,season,team}),30_000);return json(res,200,data?data.response:demoFixtures);
    }
    if(method==='GET'&&url.pathname==='/api/live'){
      const data=await cached('live',()=>footballApi('/fixtures',{live:'all'}),15_000);return json(res,200,data?data.response:demoFixtures.filter(f=>f.fixture.status.short==='LIVE'));
    }
    if(method==='GET'&&parts[0]==='api'&&parts[1]==='fixture'&&parts[2]&&parts.length===3){
      const id=parts[2],data=await cached(`fixture:${id}`,()=>footballApi('/fixtures',{id}),20_000);return json(res,200,data?.response?.[0]||demoFixtures.find(f=>String(f.fixture.id)===String(id))||demoFixtures[0]);
    }
    if(method==='GET'&&parts[0]==='api'&&parts[1]==='fixture'&&parts[2]&&parts[3]==='prediction'){
      const id=parts[2],data=await cached(`prediction:${id}`,()=>footballApi('/predictions',{fixture:id}),60*60*1000);if(data?.response?.[0])return json(res,200,predictionFromProvider(data.response[0]));const f=demoFixtures.find(x=>String(x.fixture.id)===String(id))||demoFixtures[0];return json(res,200,demoPrediction(f));
    }
    if(method==='GET'&&parts[0]==='api'&&parts[1]==='fixture'&&parts[2]&&parts[3]==='odds'){
      const data=await cached(`odds:${parts[2]}`,()=>footballApi('/odds',{fixture:parts[2]}),3*60*60*1000);return json(res,200,data?.response||[]);
    }
    if(method==='GET'&&parts[0]==='api'&&parts[1]==='fixture'&&parts[2]&&parts[3]==='h2h'){
      const id=parts[2],fd=await cached(`fixture:${id}`,()=>footballApi('/fixtures',{id}),20_000),f=fd?.response?.[0];if(!f)return json(res,200,[]);const h2h=`${f.teams.home.id}-${f.teams.away.id}`;const data=await cached(`h2h:${h2h}`,()=>footballApi('/fixtures/headtohead',{h2h,last:5}),6*60*60*1000);return json(res,200,data?.response||[]);
    }
    if(method==='POST'&&url.pathname==='/api/auth/register'){
      const b=await readBody(req),name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');if(!name||!email||password.length<6)return json(res,400,{error:'Name, valid email and password (6+ chars) are required.'});if(users.has(email))return json(res,409,{error:'An account with that email already exists.'});const ph=hashPassword(password);const u={id:id(),name,email,passwordHash:ph.hash,salt:ph.salt,favorites:[]};users.set(email,u);return json(res,201,{token:tokenFor(u),user:publicUser(u)});
    }
    if(method==='POST'&&url.pathname==='/api/auth/login'){
      const b=await readBody(req),email=String(b.email||'').trim().toLowerCase(),password=String(b.password||''),u=users.get(email);if(!u||!verifyPassword(password,u))return json(res,401,{error:'Invalid email or password.'});return json(res,200,{token:tokenFor(u),user:publicUser(u)});
    }
    if(method==='GET'&&url.pathname==='/api/me'){
      const p=userFromReq(req);if(!p)return json(res,401,{error:'Authentication required'});const u=users.get(p.email);if(!u)return json(res,404,{error:'User not found'});return json(res,200,publicUser(u));
    }
    if(method==='POST'&&url.pathname==='/api/favorites'){
      const p=userFromReq(req);if(!p)return json(res,401,{error:'Authentication required'});const u=users.get(p.email),b=await readBody(req);if(!b.type||!b.id||!b.name)return json(res,400,{error:'type, id and name are required.'});if(!u.favorites.some(x=>x.type===b.type&&String(x.id)===String(b.id)))u.favorites.push({type:b.type,id:b.id,name:b.name,logo:b.logo||''});return json(res,200,u.favorites);
    }
    if(method==='DELETE'&&url.pathname==='/api/favorites'){
      const p=userFromReq(req);if(!p)return json(res,401,{error:'Authentication required'});const u=users.get(p.email),b=await readBody(req);u.favorites=u.favorites.filter(x=>!(x.type===b.type&&String(x.id)===String(b.id)));return json(res,200,u.favorites);
    }
    return false;
  }catch(e){return json(res,502,{error:e.message||'Server error'})}
}

const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};
function serveStatic(url,res){let p=decodeURIComponent(url.pathname);if(p==='/'||p==='')p='/index.html';const full=path.normalize(path.join(PUBLIC,p));if(!full.startsWith(PUBLIC))return json(res,403,{error:'Forbidden'});fs.readFile(full,(err,data)=>{if(err){if(err.code==='ENOENT'&&p!=='/index.html')return serveStatic({pathname:'/index.html'},res);return json(res,404,{error:'Not found'});}res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream','Cache-Control':'public, max-age=300'});res.end(data);})}

const server=http.createServer(async(req,res)=>{if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS'});return res.end();}const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);if(u.pathname.startsWith('/api/')){const handled=await apiRoute(req.method,u,req,res);if(handled===false)return json(res,404,{error:'API route not found'});return;}serveStatic(u,res)});
server.listen(PORT,()=>console.log(`Mabao AI running on http://localhost:${PORT} — ${DEMO_MODE?'DEMO':'LIVE API'} mode`));
