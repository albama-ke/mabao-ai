# Mabao AI

Mabao AI is a professional football intelligence web app starter: live matches, worldwide fixtures, results, leagues, odds/prediction endpoints, user accounts, favorites, and a dedicated Mabao AI analytical layer.

## Current architecture

- Frontend: vanilla HTML/CSS/JavaScript
- Backend: Node.js + Express
- Football provider: API-Football compatible API (`https://v3.football.api-sports.io` by default)
- Authentication: JWT + bcrypt (starter in-memory user store)
- Caching: server-side in-memory cache with different TTLs for live, fixtures, predictions, odds and reference data
- Demo mode: automatically enabled when `API_FOOTBALL_KEY` is missing

## Run locally

1. Copy `.env.example` to `.env`.
2. Add your API-Football key:

```env
API_FOOTBALL_KEY=YOUR_KEY
JWT_SECRET=replace-with-a-long-random-secret
DEMO_MODE=false
```

3. Install packages:

```bash
npm install
```

4. Start:

```bash
npm start
```

Open `http://localhost:3000`.

## Important production notes

The browser never receives `API_FOOTBALL_KEY`; it stays on the server.

The included account store is intentionally a starter implementation. For real production accounts, move users, favorites and prediction history to PostgreSQL/Supabase/Firebase, add email verification, password-reset flow, rate limiting, CSRF/origin controls where appropriate, and persistent sessions/token rotation.

The Mabao AI layer should be treated as an analytical model, not a guarantee of match outcomes. It is designed to communicate probabilities and supporting data clearly.

## Main API routes

- `GET /api/live`
- `GET /api/fixtures?date=YYYY-MM-DD&timezone=Africa/Nairobi`
- `GET /api/countries`
- `GET /api/leagues?country=England`
- `GET /api/fixture/:id`
- `GET /api/fixture/:id/prediction`
- `GET /api/fixture/:id/odds`
- `GET /api/fixture/:id/h2h`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`
- `POST /api/favorites`
- `DELETE /api/favorites`

## Deployment

This app can be deployed as a single Node service on Render, Railway, Fly.io or another Node-compatible host. Set the same environment variables there and point the service start command to `npm start`.
