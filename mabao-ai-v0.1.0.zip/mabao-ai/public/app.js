const state = {
  view: 'home',
  date: new Date().toISOString().slice(0,10),
  fixtures: [],
  live: [],
  countries: [],
  leagues: [],
  currentFixture: null,
  prediction: null,
  user: null,
  token: localStorage.getItem('mabao_token') || '',
  authMode: 'register'
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function esc(v) { return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function api(path, options={}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  return fetch(path, { ...options, headers }).then(async r => {
    const data = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
    return data;
  });
}
function fmtTime(date) { try { return new Intl.DateTimeFormat(undefined,{hour:'2-digit',minute:'2-digit'}).format(new Date(date)); } catch { return '--:--'; } }
function fmtDate(date) { try { return new Intl.DateTimeFormat(undefined,{weekday:'short',day:'2-digit',month:'short'}).format(new Date(date)); } catch { return ''; } }
function isLive(f) { return ['1H','HT','2H','ET','BT','P','LIVE'].includes(f?.fixture?.status?.short); }
function score(f) { const h=f?.goals?.home, a=f?.goals?.away; return h == null && a == null ? '–' : `${h} : ${a}`; }
function statusText(f) { const s=f?.fixture?.status; if (isLive(f)) return s?.elapsed ? `${s.elapsed}'` : 'LIVE'; if (s?.short==='FT' || s?.short==='AET' || s?.short==='PEN') return s.short; return fmtTime(f?.fixture?.date); }
function logo(src, name) { return src ? `<img class="team-logo" src="${esc(src)}" alt="">` : `<div class="team-logo" style="display:grid;place-items:center;font:800 13px Space Grotesk">${esc((name||'?').slice(0,1))}</div>`; }

function matchCard(f) {
  const home=f?.teams?.home||{}, away=f?.teams?.away||{}, l=f?.league||{};
  return `<article class="match-card">
    <div class="league-row"><span class="league-label">${esc(l.name || 'Football')} · ${esc(l.country || '')}</span><span class="status-badge ${isLive(f)?'live':''}">${esc(statusText(f))}</span></div>
    <div class="teams">
      <div class="team">${logo(home.logo,home.name)}<div class="team-name">${esc(home.name)}</div></div>
      <div class="score">${esc(score(f))}</div>
      <div class="team">${logo(away.logo,away.name)}<div class="team-name">${esc(away.name)}</div></div>
    </div>
    <div class="card-bottom"><span class="tiny-muted">${esc(fmtDate(f?.fixture?.date))}</span><div class="card-actions"><button class="mini-btn" data-open-fixture="${esc(f.fixture.id)}">Details</button>${!isLive(f) ? `<button class="mini-btn ai" data-ai-fixture="${esc(f.fixture.id)}">✦ AI Analysis</button>` : ''}</div></div>
  </article>`;
}

function stackCard(f) {
  const home=f?.teams?.home||{}, away=f?.teams?.away||{}, l=f?.league||{};
  return `<article class="stack-card">
    <div><div class="stack-league">${esc(l.country || '')}</div><strong style="font-size:11px">${esc(l.name || 'Football')}</strong></div>
    <div class="stack-match"><div class="stack-team">${home.logo?`<img class="stack-mini-logo" src="${esc(home.logo)}">`:''}${esc(home.name)}</div><div><div class="stack-score">${esc(score(f))}</div><div class="stack-time">${esc(statusText(f))}</div></div><div class="stack-team away">${esc(away.name)}${away.logo?`<img class="stack-mini-logo" src="${esc(away.logo)}">`:''}</div></div>
    <div class="stack-actions"><button class="mini-btn" data-open-fixture="${esc(f.fixture.id)}">Open</button>${!isLive(f)?`<button class="mini-btn ai" data-ai-fixture="${esc(f.fixture.id)}">AI</button>`:''}</div>
  </article>`;
}

async function init() {
  $('#todayLabel').textContent = fmtDate(new Date());
  $('#fixtureDate').value = state.date;
  $('#resultsDate').value = state.date;
  bindNav(); bindGlobal();
  await Promise.all([loadHealth(), loadCountries(), loadLeagues(), loadHome()]);
  tickClock(); setInterval(tickClock, 1000);
  setInterval(loadLive, 15000);
  if (state.token) loadMe();
}

function bindNav() {
  $$('.nav-item').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
  $$('[data-view-jump]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.viewJump)));
}
function switchView(view){
  state.view=view; $$('.view').forEach(v=>v.classList.remove('active')); $(`#view-${view}`)?.classList.add('active');
  $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  if(view==='live') loadLive(); if(view==='fixtures') loadFixtures(); if(view==='results') loadResults(); if(view==='leagues') renderCountries(); if(view==='favorites') renderFavorites();
  $('#sidebar').classList.remove('open'); window.scrollTo({top:0,behavior:'smooth'});
}

function bindGlobal(){
  $('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
  $('#refreshBtn').addEventListener('click',()=>Promise.all([loadHome(),loadLive(),loadFixtures()]));
  $('#prevDate').addEventListener('click',()=>changeDate(-1)); $('#nextDate').addEventListener('click',()=>changeDate(1));
  $('#fixtureDate').addEventListener('change',e=>{state.date=e.target.value;loadFixtures()});
  $('#resultsDate').addEventListener('change',e=>{state.date=e.target.value;loadResults()});
  $('#leagueSelect').addEventListener('change',loadFixtures);
  document.body.addEventListener('click', e=>{
    const open=e.target.closest('[data-open-fixture]'); if(open) openFixture(open.dataset.openFixture);
    const ai=e.target.closest('[data-ai-fixture]'); if(ai) openFixture(ai.dataset.aiFixture,true);
    const close=e.target.closest('[data-close]'); if(close) $('#'+close.dataset.close).classList.add('hidden');
    const chip=e.target.closest('[data-league-id]'); if(chip){ $('#leagueSelect').value=chip.dataset.leagueId; switchView('fixtures'); loadFixtures(); }
    const country=e.target.closest('[data-country-leagues]'); if(country){ loadCountryLeagues(country.dataset.countryLeagues); }
    const tab=e.target.closest('[data-detail-tab]'); if(tab && state.currentFixture){ $$('.detail-tab').forEach(x=>x.classList.remove('active')); tab.classList.add('active'); loadDetailPanel(tab.dataset.detailTab); }
  });
  $('#loginPrompt').addEventListener('click',()=>openAuth()); $('#profileBtn').addEventListener('click',()=> state.user ? switchView('favorites') : openAuth());
  $('#authSwitch').addEventListener('click',()=>{state.authMode=state.authMode==='register'?'login':'register'; renderAuth();});
  $('#authForm').addEventListener('submit',handleAuth);
  $('#searchInput').addEventListener('input',handleSearch);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){ $$('.modal').forEach(m=>m.classList.add('hidden')); }});
}
function changeDate(delta){ const d=new Date(state.date+'T00:00:00'); d.setDate(d.getDate()+delta); state.date=d.toISOString().slice(0,10); $('#fixtureDate').value=state.date;$('#resultsDate').value=state.date;loadFixtures(); }

async function loadHealth(){ try {const h=await api('/api/health'); $('#api-status').textContent=h.demoMode?'Demo data active':'Live football data connected'; $('#api-status-dot').style.background=h.demoMode?'#f2c65c':'#64ff9b';}catch{ $('#api-status').textContent='Data connection unavailable'; $('#api-status-dot').style.background='#ff6879'; } }
async function loadCountries(){ try {state.countries=await api('/api/countries'); state.countries.sort((a,b)=>a.name.localeCompare(b.name)); renderCountries(); }catch(e){ $('#countries-grid').innerHTML=errorHtml(e.message); } }
async function loadLeagues(){ try {state.leagues=await api('/api/leagues'); const sel=$('#leagueSelect'); sel.innerHTML='<option value="">All leagues</option>'+state.leagues.slice(0,150).map(l=>`<option value="${esc(l.id)}">${esc(l.name)} — ${esc(l.country||'')}</option>`).join(''); }catch{} }
async function loadHome(){ $('#home-live').innerHTML=loadingHtml(); $('#home-fixtures').innerHTML=loadingHtml(); try {state.live=await api('/api/live'); $('#home-live').innerHTML=state.live.length?state.live.slice(0,3).map(matchCard).join(''):emptyHtml('No live matches right now.');}catch(e){$('#home-live').innerHTML=errorHtml(e.message)} try {state.fixtures=await api('/api/fixtures?date='+state.date+'&timezone=Africa/Nairobi'); const upcoming=state.fixtures.filter(f=>!isLive(f) && !['FT','AET','PEN'].includes(f.fixture?.status?.short)); $('#home-fixtures').innerHTML=(upcoming.length?upcoming:state.fixtures).slice(0,6).map(matchCard).join('') || emptyHtml('No fixtures found for this date.'); renderSpotlight((upcoming[0]||state.fixtures[0])); }catch(e){$('#home-fixtures').innerHTML=errorHtml(e.message)} }
async function loadLive(){ try {state.live=await api('/api/live'); const html=state.live.length?state.live.map(stackCard).join(''):emptyHtml('No matches are live at the moment.'); $('#live-list').innerHTML=html; $('#home-live').innerHTML=state.live.slice(0,3).map(matchCard).join('') || emptyHtml('No live matches right now.');}catch(e){$('#live-list').innerHTML=errorHtml(e.message)} }
async function loadFixtures(){ $('#fixtures-list').innerHTML=loadingHtml(); const league=$('#leagueSelect').value; try {state.fixtures=await api('/api/fixtures?date='+state.date+'&timezone=Africa/Nairobi'+(league?'&league='+encodeURIComponent(league):'')); $('#fixtures-list').innerHTML=state.fixtures.length?state.fixtures.map(stackCard).join(''):emptyHtml('No fixtures found for this date.');}catch(e){$('#fixtures-list').innerHTML=errorHtml(e.message)} }
async function loadResults(){ $('#results-list').innerHTML=loadingHtml(); try {const list=await api('/api/fixtures?date='+state.date+'&timezone=Africa/Nairobi'); const played=list.filter(f=>['FT','AET','PEN'].includes(f.fixture?.status?.short)); $('#results-list').innerHTML=played.length?played.map(stackCard).join(''):emptyHtml('No completed results found for this date.');}catch(e){$('#results-list').innerHTML=errorHtml(e.message)} }
function renderSpotlight(f){ if(!f){$('#home-ai').innerHTML=emptyHtml('No featured fixture available.');return;} $('#home-ai').innerHTML=`<div class="ai-copy"><div class="eyebrow">MATCH INTELLIGENCE</div><h3>${esc(f.teams.home.name)} <span style="color:#6d7d76">vs</span> ${esc(f.teams.away.name)}</h3><p>Mabao AI turns available forecast data into probabilities, confidence and a readable football narrative. Open the match for the complete analysis.</p><button class="primary-btn" data-ai-fixture="${esc(f.fixture.id)}">Generate AI Analysis →</button></div><div class="analysis-box"><div class="analysis-kicker">MODEL STATUS</div><h4>Ready to analyse</h4><p>Use the dedicated AI layer for 1X2, goals, BTTS, correct-score context, confidence and supporting reasoning.</p><div class="meter"><i style="width:82%"></i></div></div>`; }

async function loadCountryLeagues(country){ try{ const data=await api('/api/leagues?country='+encodeURIComponent(country)); state.leagues=[...state.leagues.filter(l=>l.country!==country),...data]; const sel=$('#leagueSelect'); sel.innerHTML='<option value="">All leagues</option>'+state.leagues.slice(0,250).map(l=>`<option value="${esc(l.id)}">${esc(l.name)} — ${esc(l.country||'')}</option>`).join(''); renderCountries(); }catch(e){ alert(e.message); } }
function renderCountries(letter=null){ const letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''); $('#az').innerHTML=letters.map(ch=>`<button class="${letter===ch?'active':''}" data-letter="${ch}">${ch}</button>`).join(''); $$('#az button').forEach(b=>b.addEventListener('click',()=>renderCountries(b.dataset.letter))); const list=letter?state.countries.filter(c=>c.name?.toUpperCase().startsWith(letter)):state.countries; $('#countries-grid').innerHTML=list.slice(0,120).map(c=>{const ls=state.leagues.filter(l=>l.country===c.name).slice(0,4);return `<div class="country-card"><h3>${esc(c.name)}</h3><div class="country-meta">${ls.length?ls.length+' cached competitions':'Worldwide country coverage'}</div><div class="leagues">${ls.map(l=>`<button class="league-chip" data-league-id="${esc(l.id)}">${esc(l.name)}</button>`).join('')}<button class="league-chip" data-country-leagues="${esc(c.name)}">＋ Explore ${esc(c.name)} leagues</button></div></div>`}).join('')||emptyHtml('No countries match this letter.'); }

async function openFixture(id, focusAI=false){ $('#fixtureModal').classList.remove('hidden'); $('#fixture-detail').innerHTML=loadingHtml(); try { const f=await api('/api/fixture/'+id); state.currentFixture=f; const pred=focusAI?await api('/api/fixture/'+id+'/prediction'):null; state.prediction=pred; renderFixtureDetail(f,pred); }catch(e){$('#fixture-detail').innerHTML=errorHtml(e.message)} }
function renderFixtureDetail(f,pred){ const h=f?.teams?.home||{},a=f?.teams?.away||{},l=f?.league||{}; $('#fixture-detail').innerHTML=`<div class="fixture-top"><div class="eyebrow">${esc(l.name||'Football')} · ${esc(l.country||'')}</div><span class="status-badge ${isLive(f)?'live':''}">${esc(statusText(f))}</span></div><div class="fixture-title"><div class="club">${esc(h.name)} <span style="color:#76877f">vs</span> ${esc(a.name)}</div><div class="fixture-score">${esc(score(f))}</div><div class="fixture-sub">${esc(fmtDate(f?.fixture?.date))} · ${esc(f?.fixture?.venue?.name||'Venue TBC')}</div></div><div class="detail-actions"><button class="mini-btn" onclick="toggleFavorite('${esc(h.id)}','${esc(h.name)}','${esc(h.logo||'')}')">★ Save ${esc(h.name)}</button><button class="mini-btn" onclick="toggleFavorite('${esc(a.id)}','${esc(a.name)}','${esc(a.logo||'')}')">★ Save ${esc(a.name)}</button></div><div class="detail-tabs"><button class="detail-tab active" data-detail-tab="overview">Overview</button><button class="detail-tab" data-detail-tab="ai">✦ AI</button><button class="detail-tab" data-detail-tab="odds">Odds</button><button class="detail-tab" data-detail-tab="h2h">H2H</button></div><div class="detail-panel" id="detail-panel">${overviewHtml(f)}</div>`; if(pred){ $$('.detail-tab').forEach(x=>x.classList.remove('active')); $('[data-detail-tab="ai"]').classList.add('active'); $('#detail-panel').innerHTML=predictionHtml(pred); } }
async function loadPredictionFromModal(id){ try{const p=await api('/api/fixture/'+id+'/prediction');state.prediction=p;renderFixtureDetail(state.currentFixture,p);$('#ai-lab-result').innerHTML=predictionHtml(p); }catch(e){alert(e.message)} }
function predictionHtml(p){return `<div class="prediction-head"><div><div class="eyebrow">MABAO AI</div><div style="font:700 18px Space Grotesk">${esc(p.winner)}</div><div class="tiny-muted">Model confidence</div></div><div class="prediction-score">${esc(p.confidence)}%</div></div><div class="prediction-cells"><div class="prediction-cell"><span>Home</span><strong>${esc(p.home)}%</strong></div><div class="prediction-cell"><span>Draw</span><strong>${esc(p.draw)}%</strong></div><div class="prediction-cell"><span>Away</span><strong>${esc(p.away)}%</strong></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><div class="prediction-cell"><span>Predicted score</span><strong>${esc(p.predictedScore)}</strong></div><div class="prediction-cell"><span>Goals view</span><strong style="font-size:17px">${esc(p.underOver||'—')}</strong></div></div><div class="explain"><strong>Why this view?</strong><br>${esc(p.advice)}</div>`; }
function overviewHtml(f){const v=f?.fixture?.venue||{};return `<div class="prediction-cells"><div class="prediction-cell"><span>Kickoff</span><strong style="font-size:15px">${esc(fmtTime(f?.fixture?.date))}</strong></div><div class="prediction-cell"><span>Venue</span><strong style="font-size:15px">${esc(v.name||'TBC')}</strong></div><div class="prediction-cell"><span>Round</span><strong style="font-size:15px">${esc(f?.league?.round||'—')}</strong></div></div><div class="explain"><strong>Match status</strong><br>${esc(statusText(f))}. Full event timeline, lineups and statistics can be added to this panel using the provider's match-detail payload.</div>`;}
async function loadDetailPanel(tab){const panel=$('#detail-panel');if(!panel)return;const f=state.currentFixture;panel.innerHTML=loadingHtml();try{if(tab==='overview')panel.innerHTML=overviewHtml(f);else if(tab==='ai'){const p=state.prediction||await api('/api/fixture/'+f.fixture.id+'/prediction');state.prediction=p;panel.innerHTML=predictionHtml(p);$('#ai-lab-result').innerHTML=predictionHtml(p);}else if(tab==='odds'){const data=await api('/api/fixture/'+f.fixture.id+'/odds');panel.innerHTML=oddsHtml(data);}else if(tab==='h2h'){const data=await api('/api/fixture/'+f.fixture.id+'/h2h');panel.innerHTML=h2hHtml(data);}}catch(e){panel.innerHTML=errorHtml(e.message)}}
function oddsHtml(rows){if(!rows?.length)return emptyHtml('No bookmaker odds are available for this fixture.');const books=rows.slice(0,8);return `<div class="stack-list">${books.map(r=>`<div class="stack-card" style="grid-template-columns:1fr auto"><div><div class="stack-league">BOOKMAKER</div><strong>${esc(r.bookmaker?.name||'Bookmaker')}</strong></div><div class="stack-actions"><span class="status-badge">${r?.bets?.[0]?.values?.slice(0,3).map(x=>esc(x.value)+': '+esc(x.odd)).join(' · ')||'Odds available'}</span></div></div>`).join('')}</div>`}
function h2hHtml(rows){if(!rows?.length)return emptyHtml('No recent head-to-head records found.');return `<div class="stack-list">${rows.slice(0,5).map(f=>`<div class="stack-card" style="grid-template-columns:1fr auto"><div><div class="stack-league">${esc(f.league?.name||'Competition')}</div><strong>${esc(f.teams?.home?.name)} vs ${esc(f.teams?.away?.name)}</strong></div><div class="stack-score">${esc(score(f))}</div></div>`).join('')}</div>`}


async function toggleFavorite(id,name,logo){ if(!state.token){openAuth();return;} try {const favs=await api('/api/favorites',{method:'POST',body:JSON.stringify({type:'team',id,name,logo})}); state.user.favorites=favs;renderFavorites();}catch(e){alert(e.message)} }
async function loadMe(){try{state.user=await api('/api/me');updateProfile();}catch{localStorage.removeItem('mabao_token');state.token='';}}
function renderFavorites(){const el=$('#favorites-list');if(!state.user){el.innerHTML=`<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">★</div><h3>Your teams live here</h3><p>Sign in to save clubs and quickly return to their matches.</p></div>`;return;} const fs=state.user.favorites||[]; el.innerHTML=fs.length?fs.map(x=>`<div class="favorite-card"><div class="eyebrow">TEAM</div><h3 style="font:700 17px Space Grotesk;margin:7px 0">${esc(x.name)}</h3><button class="mini-btn" onclick="switchView('fixtures')">Open fixtures</button></div>`).join(''):emptyHtml('No saved teams yet.');}
function updateProfile(){ if(!state.user)return; $('.profile-name').textContent=state.user.name.split(' ')[0]||'User';$('.avatar').textContent=(state.user.name||'U').slice(0,1).toUpperCase(); }
function openAuth(){renderAuth();$('#authModal').classList.remove('hidden');}
function renderAuth(){const register=state.authMode==='register';$('#authTitle').textContent=register?'Create your Mabao account':'Welcome back';$('#authSubtitle').textContent=register?'Save teams and personalize Mabao AI.':'Sign in to save teams and personalize Mabao AI.';$('#nameField').style.display=register?'grid':'none';$('#authSubmit').textContent=register?'Create account':'Sign in';$('#authSwitch').textContent=register?'Already have an account? Sign in':'Need an account? Create one';$('#authError').textContent='';}
async function handleAuth(e){e.preventDefault();const fd=new FormData(e.target);const body=Object.fromEntries(fd.entries());try{const data=await api(state.authMode==='register'?'/api/auth/register':'/api/auth/login',{method:'POST',body:JSON.stringify(body)});state.token=data.token;localStorage.setItem('mabao_token',state.token);state.user=data.user;$('#authModal').classList.add('hidden');updateProfile();renderFavorites();}catch(err){$('#authError').textContent=err.message}}
function handleSearch(e){const q=e.target.value.trim().toLowerCase(),box=$('#searchResults');if(!q){box.classList.add('hidden');return;} const teams=[...new Set(state.fixtures.flatMap(f=>[f.teams?.home,f.teams?.away]).filter(Boolean).map(t=>t.name))].filter(n=>n.toLowerCase().includes(q)).slice(0,8);const leagues=state.leagues.filter(l=>String(l.name).toLowerCase().includes(q)).slice(0,8).map(l=>`${l.name} — ${l.country||''}`);const items=[...teams,...leagues];box.innerHTML=items.length?items.map(x=>`<div class="search-result">${esc(x)}</div>`).join(''):emptyHtml('No quick matches.');box.classList.remove('hidden');}
function tickClock(){const now=new Date();$('#liveClock').textContent=new Intl.DateTimeFormat(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(now);}
function loadingHtml(){return '<div class="loading">Loading Mabao data…</div>'}function emptyHtml(t){return `<div class="loading">${esc(t)}</div>`}function errorHtml(t){return `<div class="error-state">${esc(t)}</div>`}

window.loadPredictionFromModal=loadPredictionFromModal;window.toggleFavorite=toggleFavorite;window.switchView=switchView;
init();
